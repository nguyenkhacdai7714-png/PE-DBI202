/* =========================================================
   DBI202 - EV Charging Station Answer SQL
========================================================= */
--drop database EVChargingDB
Create database EVChargingDB
use EVChargingDB
 CREATE TABLE Users(
     UserID INT IDENTITY(1,1) PRIMARY KEY,
     FullName NVARCHAR(100) NOT NULL,
     PhoneNumber VARCHAR(20) NOT NULL
 );
 INSERT INTO [Users](FullName, PhoneNumber) VALUES
 (N'Nguyen Van A', '0901111111'),
 (N'Tran Thi B', '0902222222'),
 (N'Le Van C', '0903333333');
 
CREATE TABLE Connector (
    ConnectorID INT IDENTITY(1,1) PRIMARY KEY,
	Description varchar(500),
    ConnectorName VARCHAR(30) NOT NULL UNIQUE,
    CONSTRAINT CK_Connector_Name
        CHECK (ConnectorName IN ('Type2', 'CCS2', 'CHAdeMO'))
);
CREATE TABLE Station (
    StationID INT IDENTITY(1,1) PRIMARY KEY,
    StationCode VARCHAR(50) NOT NULL UNIQUE,
	ConnectorID int not null,
    Type VARCHAR(20) NOT NULL DEFAULT 'NormalCharge',
    Status VARCHAR(20) NOT NULL DEFAULT 'Available',
    PricePerKwh DECIMAL(12,2) NOT NULL,
	CONSTRAINT CK_Station_Type
        CHECK (Type IN ('FastCharge', 'NormalCharge')),
    CONSTRAINT CK_Station_Status
        CHECK (Status IN ('Not Available', 'Available', 'Maintenance')),
    CONSTRAINT CK_Station_Price
        CHECK (PricePerKwh > 0),
	CONSTRAINT FK_StationConnector_Connector
        FOREIGN KEY (ConnectorID) REFERENCES Connector(ConnectorID)
);
INSERT INTO Connector(ConnectorName) VALUES
('Type2'), ('CCS2'), ('CHAdeMO');
INSERT INTO Station(ConnectorID, StationCode, Type, Status, PricePerKwh) VALUES
(1,'EV-FAST-HANOI-01', 'FastCharge', 'Available', 3850),
(1,'EV-NORMAL-DN-01', 'NormalCharge', 'Available', 3200),
(1,'EV-FAST-HCM-01', 'FastCharge', 'Maintenance', 3900);

--The answer to question 2 is here:

--End question 2


--The answer to question 3 is here:

--End question 3


--The answer to question 4 is here:

--End question 4


--The answer to question 5 is here:

--End question 5